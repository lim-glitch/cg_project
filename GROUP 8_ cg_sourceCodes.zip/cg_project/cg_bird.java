/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cg_project;

/**
 *
 * @author Acer
 */
import javax.swing.JFrame;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.glu.GLUquadric;

public class cg_bird {
    private float x, y;
    private GLU glu = new GLU();
    
    public cg_bird(float x, float y){
        this.x = x;
        this.y = y;
    }
    
    public void drawBird(GL2 gl) {
        GLUquadric quad = glu.gluNewQuadric();
        gl.glPushMatrix();
        
        // Use the x, y position parameters
        gl.glTranslatef(x, y, 0f); // Position the bird using constructor parameters
        
        // Scale down the entire bird to make it smaller but still visible
        gl.glScalef(0.3f, 0.3f, 0.3f); 
        
        // body use sphere
        gl.glColor3f(0.7f, 0.4f, 0.1f); // Brownish
        gl.glPushMatrix();
        gl.glScalef(1.2f, 0.9f, 0.9f);  // Oval body shape
        glu.gluSphere(quad, 0.3, 32, 32);
        gl.glPopMatrix();
        
        // head use smaller sphere
        gl.glPushMatrix();
        gl.glTranslatef(0.35f, 0.15f, 0.0f); // to the right of body
        glu.gluSphere(quad, 0.15, 32, 32);
        gl.glPopMatrix();
        
        // beak use cone
        gl.glColor3f(1.0f, 0.8f, 0.1f); // Yellow
        gl.glPushMatrix();
        gl.glTranslatef(0.5f, 0.15f, 0.0f); // in front of head
        gl.glRotatef(90f, 0f, 1f, 0f); // point to side
        glu.gluCylinder(quad, 0.03, 0.0, 0.12, 16, 1);
        gl.glPopMatrix();
        
        // eye use small sphere
        gl.glColor3f(0f, 0f, 0f); // Black
        gl.glPushMatrix();
        gl.glTranslatef(0.40f, 0.2f, 0.11f); // slight to the front-right
        glu.gluSphere(quad, 0.025, 16, 16);
        gl.glPopMatrix();
        
        // left wing use triangle
        gl.glColor3f(0.3f, 0.3f, 0.7f); // Bluish
        gl.glPushMatrix();
        gl.glTranslatef(0.0f, 0.0f, 0.3f);
        gl.glRotatef(45, 1, 0, 0);
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex3f(0.0f, 0.0f, 0.0f);
        gl.glVertex3f(-0.4f, 0.2f, 0.0f);
        gl.glVertex3f(-0.4f, -0.2f, 0.0f);
        gl.glEnd();
        gl.glPopMatrix();
        
        // right wing
        gl.glColor3f(0.3f, 0.3f, 0.7f);
        gl.glPushMatrix();
        gl.glTranslatef(0.0f, 0.0f, -0.3f);
        gl.glRotatef(-45, 1, 0, 0);
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex3f(0.0f, 0.0f, 0.0f);
        gl.glVertex3f(-0.4f, 0.2f, 0.0f);
        gl.glVertex3f(-0.4f, -0.2f, 0.0f);
        gl.glEnd();
        gl.glPopMatrix();
        
        // tail use triangle
        gl.glColor3f(0.5f, 0.3f, 0.2f);
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glVertex3f(-0.35f, 0.0f, 0.0f);
        gl.glVertex3f(-0.55f, 0.1f, 0.1f);
        gl.glVertex3f(-0.55f, -0.1f, -0.1f);
        gl.glEnd();
        
        gl.glPopMatrix();
        glu.gluDeleteQuadric(quad);
    }
}