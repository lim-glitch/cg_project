package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.Animator;
import com.jogamp.opengl.util.gl2.GLUT;

import javax.swing.*;

public class CloudRenderer{
    private float x,y;
    private final GLUT glut = new GLUT();

    public CloudRenderer(float x, float y){
        this.x = x;
        this.y = y;
    }

    public void drawCloud(GL2 gl, float x, float y) {
        gl.glPushMatrix();
        gl.glTranslatef(x, y, -0.5f); // Position the cloud

        // Main puff color
        gl.glColor3f(1.0f, 1.0f, 1.0f); // pure white

        // Draw puff spheres (high-res)
        glut.glutSolidSphere(0.08, 40, 40);
        gl.glTranslatef(0.1f, 0.02f, -0.01f);
        glut.glutSolidSphere(0.1, 40, 40);
        gl.glTranslatef(0.1f, -0.02f, 0.01f);
        glut.glutSolidSphere(0.07, 40, 40);

        // Optional translucent puff (adds softness — try toggling)
        gl.glEnable(GL2.GL_BLEND);
        gl.glColor4f(1.0f, 1.0f, 1.0f, 0.3f);
        gl.glTranslatef(-0.15f, 0.01f, -0.02f);
        glut.glutSolidSphere(0.09, 40, 40);
        gl.glDisable(GL2.GL_BLEND);

        gl.glPopMatrix();
    }
}