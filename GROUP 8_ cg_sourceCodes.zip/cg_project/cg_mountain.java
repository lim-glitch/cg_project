/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cg_project;

/**
 *
 * @author Acer
 */
import com.jogamp.opengl.*;

public class cg_mountain {
    private float x,y,z;
    private float scale;
    
    public cg_mountain(float x, float y, float z, float scale){
        this.x = x;
        this.y = y;
        this.z = z;
        this.scale = scale;
    }

    public void draw3DMountains(GL2 gl) {
        gl.glPushMatrix();
        gl.glTranslatef(x, y, z); // Position the mountain
        gl.glScalef(scale, scale, scale); // Scale the mountain
        
        // Central Mountain 
        gl.glBegin(GL2.GL_TRIANGLES);

        // Front left face - slightly darker for shadow
        gl.glColor3f(0.3f, 0.6f, 0.3f);
        gl.glNormal3f(-0.5f, 0.5f, 1);  // simulate lighting angle
        gl.glVertex3f(-0.6f, -0.4f, 0.0f);
        gl.glVertex3f(0.0f, 0.6f + noise(0), 0.05f);//slighly forward
        gl.glVertex3f(0.0f, -0.3f + noise(0), -0.05f);

        // Front right face - brighter
        gl.glColor3f(0.4f, 0.8f, 0.4f);
        gl.glNormal3f(0.5f, 0.5f, 1);
        gl.glVertex3f(0.0f, -0.4f + noise(2), -0.05f);
        gl.glVertex3f(0.0f, 0.55f+ noise(3), 0.05f);
        gl.glVertex3f(0.6f, -0.4f + noise(4), 0.0f);
        gl.glEnd();

        // Left smaller mountain - also with 2 faces
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glColor3f(0.25f, 0.5f, 0.25f);
        gl.glNormal3f(-0.5f, 0.5f, 1);
        gl.glVertex3f(-0.9f, -0.4f, 0.0f);
        gl.glVertex3f(-0.3f, 0.5f , 0.05f);
        gl.glVertex3f(0.1f, -0.4f + noise(6), -0.05f);

        gl.glColor3f(0.3f, 0.7f, 0.3f);
        gl.glNormal3f(0.5f, 0.5f, 1);
        gl.glVertex3f(-0.3f, -0.4f , 0.0f);
        gl.glVertex3f(-0.3f, 0.5f, 0.0f);
        gl.glVertex3f(0.1f, -0.4f, 0.0f);
        gl.glEnd();

        // Right mountain with more steep face
        gl.glBegin(GL2.GL_TRIANGLES);
        gl.glColor3f(0.35f, 0.6f, 0.35f);
        gl.glNormal3f(-0.6f, 0.4f, 1);
        gl.glVertex3f(0.3f, -0.4f + noise(7), 0.0f);
        gl.glVertex3f(0.7f, 0.4f + noise(8), 0.0f);
        gl.glVertex3f(0.7f, -0.4f + noise(9), 0.0f);

        gl.glColor3f(0.4f, 0.9f, 0.4f);
        gl.glNormal3f(0.6f, 0.4f, 1);
        gl.glVertex3f(0.7f, -0.4f, 0.0f);
        gl.glVertex3f(0.7f, 0.4f, 0.0f);
        gl.glVertex3f(1.0f, -0.4f, 0.0f);
        gl.glEnd();
}
       
    //added noise for more texture
    private float noise(int seed){
        double raw = Math.sin(seed*12.9898 + seed*78.233) *43758.5453;
        return (float)((raw - Math.floor(raw)) * 0.08 - 0.04);
    }
}