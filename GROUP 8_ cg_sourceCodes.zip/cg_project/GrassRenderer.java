package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.FPSAnimator;
import javax.swing.*;

public class GrassRenderer{
    private float x,y, scale;
    
    public GrassRenderer(float x, float y, float scale){
        this.x = x;
        this.y = y;
        this.scale = scale;
    }

    public void drawAllGrass(GL2 gl){
        gl.glPushMatrix();
        gl.glTranslatef(x,y,0f);
        gl.glScalef(scale, 1.0f, scale);
        
        drawGrassRow(gl, -0.6f, true);  // first row: big-small
        drawGrassRow(gl, -0.8f, false); // second row: small-big
    }

    // draw a row of grass with alternating big-small pattern
    private void drawGrassRow(GL2 gl, float baseY, boolean startWithBig) {
        float x = -1.0f;
        int index = 0;

        while (x < 1.0f) {
            boolean isBig = (index % 2 == 0) == startWithBig;

            float width = isBig ? 0.12f : 0.08f;
            float height = isBig ? 0.22f : 0.15f;

            // left triangle (dark)
            gl.glColor3f(0.0f, 0.45f, 0.0f);
            gl.glBegin(GL2.GL_TRIANGLES);
            gl.glVertex2f(x, baseY);
            gl.glVertex2f(x + width / 2, baseY + height);
            gl.glVertex2f(x + width / 2, baseY);
            gl.glEnd();

            // right triangle (light)
            gl.glColor3f(0.0f, 0.75f, 0.0f);
            gl.glBegin(GL2.GL_TRIANGLES);
            gl.glVertex2f(x + width / 2, baseY);
            gl.glVertex2f(x + width, baseY);
            gl.glVertex2f(x + width / 2, baseY + height);
            gl.glEnd();

            x += width + 0.01f;
            index++;
        }
    }
}
