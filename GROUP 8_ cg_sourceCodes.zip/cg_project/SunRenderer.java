package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.gl2.GLUT;

public class SunRenderer {
    private float x,y,z;
    private float radius;
    private final GLUT glut = new GLUT();
    
    public SunRenderer(float x,float y,float z, float radius){
        this.x = x;
        this.y = y;
        this.z = z;
        this.radius = radius;
    }
    public SunRenderer(float x, float y) {
        this(x, y, -10.0f,0.3f); // Default radius
    }
    
    public void drawSun(GL2 gl) {
        gl.glPushMatrix();
        gl.glTranslatef(x,y, z); // position in sky

        // Sun core
        gl.glColor3f(1.0f, 1.0f, 0.0f); // bright yellow
        GLUT glut = new GLUT();
        glut.glutSolidSphere(radius, 20, 20); // higher-res sphere

        // Optional glow layer (subtle)
        gl.glColor4f(1.0f, 1.0f, 0.0f, 0.1f); // translucent yellow
        glut.glutSolidSphere(radius*1.5f,20,20);

        gl.glPopMatrix();
    }
}

