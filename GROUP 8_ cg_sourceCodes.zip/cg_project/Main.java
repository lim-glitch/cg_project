/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.Animator;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.glu.GLU;
        
import javax.swing.*;

/**
 *
 * @author Acer
 */
public class Main implements GLEventListener {
    // Declare all objects
    private SunRenderer sun;
    private CloudRenderer cloud;
    private BuildingScene buildings;
    private cg_mountain mountain;
    private HumanRenderer human;
    private RoadRenderer road;
    private GrassRenderer grass;
    private TreeRenderer[] trees; 
    private LampPostRenderer[] lampPosts;
    private BenchRenderer bench;
    private cg_bird bird;
    private CatRenderer cat;
    private float time = 0f;
    private final GLU glu = new GLU();

    @Override
    public void init(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glShadeModel(GL2.GL_SMOOTH);
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);

        float[] ambientLight = {0.3f, 0.3f, 0.3f, 1.0f};
        float[] diffuseLight = {0.8f, 0.8f, 0.8f, 1.0f};
        float[] lightPosition = {5f, 5f, 10f, 1.0f};

        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, ambientLight, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, diffuseLight, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, lightPosition, 0);
        
        // let colors react to lighting
        gl.glEnable(GL2.GL_COLOR_MATERIAL);
        gl.glColorMaterial(GL2.GL_FRONT, GL2.GL_AMBIENT_AND_DIFFUSE);

        // enable blending (for transparent glow effects)
        gl.glEnable(GL2.GL_BLEND);
        gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);

        //anti-aliasing
        gl.glEnable(GL2.GL_LINE_SMOOTH);
        gl.glHint(GL2.GL_LINE_SMOOTH_HINT, GL2.GL_NICEST);

        //set sky blue background
        gl.glClearColor(0.6f, 0.85f, 1.0f, 1.0f);

        // initialize objects with corrected positioning and scaling
        sun = new SunRenderer(-1.5f, 2.5f, -10.0f, 0.3f);        // Top-left in sky
        cloud = new CloudRenderer(1.0f, 2.2f);                   // Top-right in sky  
        bird = new cg_bird(0.95f, 1.0f);                         
        
        // background elements - positioned in visible range
        buildings = new BuildingScene(-1.0f, -0.68f, -2.0f, 0.3f); // Left side, closer and larger
        mountain = new cg_mountain(0.0f, -0.1f, -3.5f, 4.0f);     // Wider mountain, closer
        
        // ground elements 
        grass = new GrassRenderer(0.0f, -0.5f, 4.0f);            // Larger grass coverage
        
        // road - shortened stop until same line as mountain 
        road = new RoadRenderer(0.0f, -1.0f, 4.0f);              
        
        // tree
        trees = new TreeRenderer[]{
            new TreeRenderer(0.4f,-0.5f)
        };
        
        // park furniture - lamp posts 
        lampPosts = new LampPostRenderer[]{
            new LampPostRenderer(0.4f,-0.5f) //right
        };
        
        // bench positioned in the park
        bench = new BenchRenderer(0.3f, -1.1f, 0.25f);           // Right-center area
        
        // Characters - smaller and positioned at bottom corners
        human = new HumanRenderer(-1.5f, -1.3f, 0.4f);              // Bottom-left, smaller scale
        cat = new CatRenderer(1.5f, -1.8f, 0.3f);               // Bottom-right, smaller scale
    }
   
    @Override
    public void dispose(GLAutoDrawable drawable) {}

    @Override
    public void display(GLAutoDrawable drawable) {
        time += 0.1f;
        
        final GL2 gl = drawable.getGL().getGL2();
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();
        
        glu.gluLookAt(0, 2, 10,  // Camera position in front
              0, 1, 0,  // Look at origin
              0, 1, 0); // Up direction
        
        // Draw all objects 
        // Background first
        mountain.draw3DMountains(gl);
        buildings.drawAllBuildings(gl);
        
        // Sky elements
        sun.drawSun(gl);
        cloud.drawCloud(gl, -0.8f, 0.8f);    // Left cloud
        cloud.drawCloud(gl, 0.7f, 0.8f);     // Right cloud
        bird.drawBird(gl);   // Bird now handles its own positioning and scaling   
        
        // Ground and park elements
        grass.drawAllGrass(gl);               // Draw grass first 
        road.drawPathway(gl);                 // Road on top of grass
        
        // Park furniture and vegetation
        for (TreeRenderer t : trees) t.drawTree(gl, 2);
        for (LampPostRenderer l : lampPosts) l.drawLamp(gl, 1);
        bench.drawBench(gl); 
        
        // Characters (drawn last, in foreground)
        human.drawHuman(gl, time); 
        cat.updateTailAnimation();
        cat.drawCat(gl);
    }
    
    @Override
    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        final GL2 gl = drawable.getGL().getGL2();
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        
        //prevent divide by zero
        if(height == 0){
            height = 1;
        }
        float aspect = (float) width/height;
        glu.gluPerspective(45.0, aspect, 1.0, 100.0);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
    }
    
    public static void main(String[] args) {
        final JFrame frame = new JFrame("Park in the City");
        final GLProfile profile = GLProfile.get(GLProfile.GL2);
        final GLCapabilities capabilities = new GLCapabilities(profile);
        final GLCanvas canvas = new GLCanvas(capabilities);
        Main scene = new Main();
        canvas.addGLEventListener(scene);
        frame.getContentPane().add(canvas);
        frame.setSize(1000, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        final Animator animator = new Animator(canvas);
        animator.start();
    }
}
