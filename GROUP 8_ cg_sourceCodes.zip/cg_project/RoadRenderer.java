package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.Animator;

import javax.swing.*;

public class RoadRenderer{
    private final GLU glu = new GLU();
    private float x,y;
    private float scale;
    
    public RoadRenderer(float x, float y, float scale){
        this.x = x;
        this.y = y;
        this.scale = scale;
    }
    
    public void drawPathway(GL2 gl) {
        gl.glPushMatrix();
        gl.glTranslatef(x,y,0f);
        gl.glScalef(scale, 1.0f, scale);
        
        // Road dimensions - shortened to stop before mountain
        float length = 6.0f;  // Reduced from 10.0f to 6.0f
        float width = 0.8f;   // Slightly wider for better visibility
        float height = 0.1f;
        float topY = -0.2f;
        float bottomY = topY - height;
        float halfLength = length / 2;
        float halfWidth = width / 2;
        
        gl.glBegin(GL2.GL_QUADS);
        gl.glColor3f(0.4f, 0.4f, 0.4f); // Asphalt gray color for road
        
        // Top face (normal up)
        gl.glNormal3f(0.0f, 1.0f, 0.0f);
        gl.glVertex3f(-halfLength, topY, -halfWidth);
        gl.glVertex3f(halfLength, topY, -halfWidth);
        gl.glVertex3f(halfLength, topY, halfWidth);
        gl.glVertex3f(-halfLength, topY, halfWidth);
        
        // Bottom face (normal down)
        gl.glNormal3f(0.0f, -1.0f, 0.0f);
        gl.glVertex3f(-halfLength, bottomY, halfWidth);
        gl.glVertex3f(halfLength, bottomY, halfWidth);
        gl.glVertex3f(halfLength, bottomY, -halfWidth);
        gl.glVertex3f(-halfLength, bottomY, -halfWidth);
        
        // Front face
        gl.glNormal3f(0.0f, 0.0f, 1.0f);
        gl.glVertex3f(-halfLength, bottomY, halfWidth);
        gl.glVertex3f(-halfLength, topY, halfWidth);
        gl.glVertex3f(halfLength, topY, halfWidth);
        gl.glVertex3f(halfLength, bottomY, halfWidth);
        
        // Back face
        gl.glNormal3f(0.0f, 0.0f, -1.0f);
        gl.glVertex3f(-halfLength, bottomY, -halfWidth);
        gl.glVertex3f(halfLength, bottomY, -halfWidth);
        gl.glVertex3f(halfLength, topY, -halfWidth);
        gl.glVertex3f(-halfLength, topY, -halfWidth);
        
        // Left face
        gl.glNormal3f(-1.0f, 0.0f, 0.0f);
        gl.glVertex3f(-halfLength, bottomY, -halfWidth);
        gl.glVertex3f(-halfLength, topY, -halfWidth);
        gl.glVertex3f(-halfLength, topY, halfWidth);
        gl.glVertex3f(-halfLength, bottomY, halfWidth);
        
        // Right face
        gl.glNormal3f(1.0f, 0.0f, 0.0f);
        gl.glVertex3f(halfLength, bottomY, -halfWidth);
        gl.glVertex3f(halfLength, bottomY, halfWidth);
        gl.glVertex3f(halfLength, topY, halfWidth);
        gl.glVertex3f(halfLength, topY, -halfWidth);
        
        gl.glEnd();
        
        // Draw road markings (center line)
        gl.glPushMatrix();
        gl.glTranslatef(0f, 0.01f, 0f); // Slightly above road surface
        gl.glColor3f(1.0f, 1.0f, 0.8f); // Light yellow for road markings
        
        // Dashed center line
        float dashLength = 0.3f;
        float gapLength = 0.2f;
        float markingWidth = 0.05f;
        int numDashes = (int)(length / (dashLength + gapLength));
        
        for(int i = 0; i < numDashes; i++) {
            float startX = -halfLength + i * (dashLength + gapLength);
            float endX = startX + dashLength;
            
            if(endX > halfLength) endX = halfLength;
            
            gl.glBegin(GL2.GL_QUADS);
            gl.glVertex3f(startX, 0f, -markingWidth/2);
            gl.glVertex3f(endX, 0f, -markingWidth/2);
            gl.glVertex3f(endX, 0f, markingWidth/2);
            gl.glVertex3f(startX, 0f, markingWidth/2);
            gl.glEnd();
        }
        
        gl.glPopMatrix();
        gl.glPopMatrix();
    }
}