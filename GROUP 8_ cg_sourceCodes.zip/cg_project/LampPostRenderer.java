package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.FPSAnimator;
import javax.swing.*;

public class LampPostRenderer{
    private float x,y;
    
    public LampPostRenderer(float x, float y){
        this.x = x;
        this.y = y;
    }

    public void drawLamp(GL2 gl, float x) {
        float baseY = -0.6f;
        float topY = 0.4f;
        float halfW = 0.025f;

        // Lamp post - left
        gl.glColor3f(0.1f, 0.1f, 0.1f);
        gl.glBegin(GL2.GL_QUADS);
        gl.glVertex3f(x - halfW, baseY, 0f);
        gl.glVertex3f(x, baseY, 0f);
        gl.glVertex3f(x, topY, 0f);
        gl.glVertex3f(x - halfW, topY, 0f);
        gl.glEnd();

        // Lamp post - right
        gl.glColor3f(0.4f, 0.4f, 0.4f);
        gl.glBegin(GL2.GL_QUADS);
        gl.glVertex3f(x, baseY, 0f);
        gl.glVertex3f(x + halfW, baseY, 0f);
        gl.glVertex3f(x + halfW, topY, 0f);
        gl.glVertex3f(x, topY, 0f);
        gl.glEnd();

        // Base - bottom
        gl.glColor3f(0.2f, 0.2f, 0.2f);
        gl.glBegin(GL2.GL_QUADS);
        gl.glVertex2f(x - 0.035f, topY);
        gl.glVertex2f(x + 0.035f, topY);
        gl.glVertex2f(x + 0.03f, topY + 0.025f);
        gl.glVertex2f(x - 0.03f, topY + 0.025f);
        gl.glEnd();

        // Base - top
        gl.glColor3f(0.4f, 0.4f, 0.4f);
        gl.glBegin(GL2.GL_QUADS);
        gl.glVertex2f(x - 0.025f, topY + 0.025f);
        gl.glVertex2f(x + 0.025f, topY + 0.025f);
        gl.glVertex2f(x + 0.02f, topY + 0.045f);
        gl.glVertex2f(x - 0.02f, topY + 0.045f);
        gl.glEnd();

        // Enlarged outer glow
        drawCircle(gl, x, topY + 0.1f, 0.075f, 1.0f, 0.85f, 0.25f);

        // Enlarged inner light bulb
        drawCircle(gl, x, topY + 0.1f, 0.06f, 1.0f, 1.0f, 0.0f);

        // Highlight reflection
        drawCircle(gl, x + 0.02f, topY + 0.12f, 0.014f, 1.0f, 1.0f, 1.0f);
    }

    private void drawCircle(GL2 gl, float cx, float cy, float r, float red, float green, float blue) {
        gl.glColor3f(red, green, blue);
        gl.glBegin(GL2.GL_TRIANGLE_FAN);
        gl.glVertex2f(cx, cy);
        for (int i = 0; i <= 100; i++) {
            double angle = 2 * Math.PI * i / 100;
            float x = (float)(cx + r * Math.cos(angle));
            float y = (float)(cy + r * Math.sin(angle));
            gl.glVertex2f(x, y);
        }
        gl.glEnd();
    }
}
