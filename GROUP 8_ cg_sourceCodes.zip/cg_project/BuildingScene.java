/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cg_project;

import com.jogamp.opengl.*;

public class BuildingScene{
    private float x,y,z;
    private float scale;
   
    public BuildingScene(float x, float y, float z, float scale){
        this.x = x;
        this.y = y;
        this.z = z;
        this.scale = scale;
    }
     //constructor for default scale
    public BuildingScene(float x, float y) {
        this(x, y, -3.0f, 0.15f); // reduced scale by default for smaller buildings
    }
    
    public void drawAllBuildings(GL2 gl){
        gl.glPushMatrix();
        gl.glTranslatef(x,y,z);
        gl.glScalef(scale, scale, scale); 
        drawBuilding(gl, -3.0f, 0f, 0f, 1.5f, 2f, 1.5f, new float[]{0.0f, 0.6f, 0.9f});
        drawBuilding(gl, -1.7f, 0f, 0f, 1.5f, 4f, 1.5f, new float[]{0.6f, 0.6f, 0.9f});
        drawBuilding(gl, -0.6f, 0f, 0f, 1.5f, 2.5f, 1.5f, new float[]{0.9f, 0.4f, 0.4f});
        drawBuilding(gl, 0.7f, 0f, 0f, 1f, 3.5f, 1f, new float[]{0.4f, 0.9f, 0.4f});
        drawBuilding(gl, 2.2f, 0f, 0f, 1.5f, 3f, 1f, new float[]{0.8f, 0.8f, 0.2f});
        gl.glPopMatrix();
    }
 
    private void drawBuilding(GL2 gl, float x, float y, float z, float width, float height, float depth, float[] color) {
        gl.glPushMatrix();
        gl.glTranslatef(x, y + height / 2f, z);

        gl.glScalef(width, height, depth);

        gl.glColor3fv(color, 0);
        drawLitCube(gl);
        
        gl.glPopMatrix();

        // Draw windows on the front face
        drawWindows(gl, x, y, z + depth / 2f + 0.01f, width, height, color);
    }

    private void drawWindows(GL2 gl, float x, float y, float z, float width, float height, float[] buildingColor) {
        gl.glColor3f(0.2f, 0.4f, 0.8f); // window color (blueish)

        int rows = (int) (height * 1.2);
        int cols = (int) (width * 2);
        float windowWidth = width / cols * 0.6f;
        float windowHeight = height / rows * 0.6f;
        float spacingX = width / cols;
        float spacingY = height / rows;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                float winX = x - width / 2 + j * spacingX + spacingX / 2;
                float winY = y + i * spacingY + spacingY / 2;

                gl.glBegin(GL2.GL_QUADS);
                gl.glVertex3f(winX - windowWidth / 2, winY - windowHeight / 2, z);
                gl.glVertex3f(winX + windowWidth / 2, winY - windowHeight / 2, z);
                gl.glVertex3f(winX + windowWidth / 2, winY + windowHeight / 2, z);
                gl.glVertex3f(winX - windowWidth / 2, winY + windowHeight / 2, z);
                gl.glEnd();
            }
        }
    }

    private void drawLitCube(GL2 gl) {
        float[][] vertices = {
            {-0.5f, -0.5f, 0.5f}, {0.5f, -0.5f, 0.5f},
            {0.5f, 0.5f, 0.5f}, {-0.5f, 0.5f, 0.5f},
            {-0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, -0.5f},
            {0.5f, 0.5f, -0.5f}, {-0.5f, 0.5f, -0.5f}
        };

        int[][] faces = {
            {0, 1, 2, 3}, // front
            {1, 5, 6, 2}, // right
            {5, 4, 7, 6}, // back
            {4, 0, 3, 7}, // left
            {3, 2, 6, 7}, // top
            {4, 5, 1, 0} // bottom
        };

        float[][] normals = {
            {0, 0, 1}, {1, 0, 0}, {0, 0, -1},
            {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}
        };

        for (int i = 0; i < faces.length; i++) {
            gl.glBegin(GL2.GL_QUADS);
            gl.glNormal3fv(normals[i], 0);
            for (int idx : faces[i]) {
                gl.glVertex3fv(vertices[idx], 0);
            }
            gl.glEnd();
        }
    }

}
