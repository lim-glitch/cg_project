/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cg_project;

/**
 *
 * @author Acer
 */
import com.jogamp.opengl.*;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.glu.GLUquadric;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.gl2.GLUT;
import com.jogamp.opengl.util.FPSAnimator;
import javax.swing.*;

public class HumanRenderer {
    private float x, y;
    private float scale;
    private final GLU glu = new GLU();

    public HumanRenderer(float x, float y, float scale) {
        this.x = x;
        this.y = y;
        this.scale = scale;
    }

    public HumanRenderer(float x, float y) {
        this(x, y, 0.3f);
    }

    public void drawHuman(GL2 gl, float time) {
       float bounce = (float) Math.abs(Math.sin(time)) * 0.05f;
       float legSwing = (float) Math.sin(time) * 30f;
       float armSwing = (float) Math.sin(time) * 20f;

       GLUquadric quad = glu.gluNewQuadric();

       // Start drawing the entire human 
       gl.glPushMatrix();
       gl.glTranslatef(x, y + bounce, 0f);
       gl.glScalef(scale, scale, scale);

       // legs
       gl.glColor3f(0.2f, 0.2f, 0.5f); // pants
       float[][] legs = {{-0.12f, -legSwing}, {0.12f, legSwing}};
       for (float[] leg : legs) {
          gl.glPushMatrix();
          gl.glTranslatef(leg[0], 0.3f, 0f); // base position
          gl.glRotatef(leg[1], 1f, 0f, 0f); // leg swing
          gl.glRotatef(90, 1f, 0f, 0f);     // stand up
          glu.gluCylinder(quad, 0.08f, 0.08f, 0.8f, 16, 16); // upper leg
          gl.glPopMatrix();
       }

       // body
       gl.glColor3f(0f, 0f, 1f); // blue shirt
       gl.glPushMatrix();
       gl.glTranslatef(0f, 0.9f, 0f); // body stands above legs
       gl.glScalef(0.5f, 1.2f, 0.3f);
       glu.gluSphere(quad, 0.5, 32, 32);
       gl.glPopMatrix();

       // arms
       gl.glColor3f(1f, 0.8f, 0.6f); // skin
       float[][] arms = {{-0.35f, armSwing}, {0.35f, -armSwing}};
       for (float[] arm : arms) {
         gl.glPushMatrix();
         gl.glTranslatef(arm[0], 1.3f, 0f); // shoulder height
         gl.glRotatef(arm[1], 1f, 0f, 0f); // swing
         gl.glRotatef(90, 1f, 0f, 0f);     // orient down
         glu.gluCylinder(quad, 0.06f, 0.06f, 0.6f, 16, 16); // upper arm
         gl.glPopMatrix();
       }

       // head
       gl.glPushMatrix();
       gl.glTranslatef(0f, 1.7f, 0f); // on top of body
       gl.glColor3f(1f, 0.8f, 0.6f); // skin
       glu.gluSphere(quad, 0.25, 32, 32); // head

       // sunglasses
       gl.glPushMatrix();
       gl.glTranslatef(0f, 0.05f, 0.22f); // position in front of head
       gl.glScalef(1.0f, 0.3f, 0.1f);     // wide, flat shape
       gl.glColor3f(0f, 0f, 0f);          // black glasses
       glu.gluSphere(quad, 0.25, 20, 20); 
       gl.glPopMatrix();

       gl.glPopMatrix(); // end head


    gl.glPopMatrix(); // end whole human
    glu.gluDeleteQuadric(quad);
   }
}
