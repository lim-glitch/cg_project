package cg_project;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.gl2.GLUT;
import com.jogamp.opengl.util.FPSAnimator;

import javax.swing.*;

public class BenchRenderer{
    private float x, y;
    private float scale;
    private final GLUT glut = new GLUT();
    
    public BenchRenderer(float x, float y, float scale){
        this.x = x;
        this.y = y;
        this.scale = scale;
    }
    public BenchRenderer(float x, float y){
        this(x,y,0.15f);
    }

    public void drawBench(GL2 gl) {
        gl.glPushMatrix();
        
        //position and scale the bench
        gl.glTranslatef(x,y,0f);
        gl.glScalef(scale,scale,scale);
        
        // set color
        gl.glColor3f(0.6f, 0.3f, 0.1f); // brown
        
        // Seat
        gl.glPushMatrix();
        gl.glTranslatef(0, 1, 0);
        gl.glScalef(4, 0.2f, 1);
        drawCube(gl);
        gl.glPopMatrix();

        // Backrest
        gl.glPushMatrix();
        gl.glTranslatef(0, 1.8f, -0.4f);
        gl.glScalef(4, 1.0f, 0.2f);
        drawCube(gl);
        gl.glPopMatrix();

        // Legs
        float[][] legPositions = {
            {-1.8f, 0.5f, 0.4f}, {1.8f, 0.5f, 0.4f},
            {-1.8f, 0.5f, -0.4f}, {1.8f, 0.5f, -0.4f}
        };

        for (float[] pos : legPositions) {
            gl.glPushMatrix();
            gl.glTranslatef(pos[0], pos[1], pos[2]);
            gl.glScalef(0.2f, 1.0f, 0.2f);
            drawCube(gl);
            gl.glPopMatrix();
        }
        
        gl.glPopMatrix(); // pop main bench transform
    }

    private void drawCube(GL2 gl) {
        glut.glutSolidCube(1.0f);
    }
}
